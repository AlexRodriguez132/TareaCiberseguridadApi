from pydantic import BaseModel

class CategoriaBase(BaseModel):
    nombre: str
    descripcion: str

class Categoria(CategoriaBase):
    id: int
    
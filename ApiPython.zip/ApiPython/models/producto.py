from pydantic import BaseModel

class ProductoBase(BaseModel):
    nombre: str
    descripcion: str
    precio: float
    marca: str
    categoria_id: int
    stock: int
    estado: bool

class Producto(ProductoBase):
    id: int
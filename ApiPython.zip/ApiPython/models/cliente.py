from pydantic import BaseModel

class ClienteBase(BaseModel):
    nombre: str
    telefono: str
    correo: str
    direccion: str
    totalCompras: float
    estado: bool

class Cliente(ClienteBase):
    id:int
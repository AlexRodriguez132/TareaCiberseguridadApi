from fastapi import FastAPI
from starlette.middleware.cors import CORSMiddleware
from routes.categorias import router as categorias_router
from routes.productos import router as productos_router
from routes.clientes import router as clientes_router
app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"]
)
app.include_router(productos_router)
app.include_router(categorias_router)
app.include_router(clientes_router)
from models.producto import Producto
productos = [
    Producto(
        id=1,
        nombre="Coca-Cola",
        descripcion="Refresco de cola",
        precio=25.0,
        marca="Coca-Cola",
        categoria_id=1,
        stock=20,
        estado=True
    ),
    Producto(
        id=2,
        nombre="Mazapán",
        descripcion="Dulce tradicional de cacahuate",
        precio=12.0,
        marca="De la Rosa",
        categoria_id=2,
        stock=35,
        estado=True
    )
]
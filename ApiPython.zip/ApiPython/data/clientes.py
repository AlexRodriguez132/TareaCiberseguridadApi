from models.cliente import Cliente

clientes = [
    Cliente(
        id=1,
        nombre="Carlos Hernández",
        telefono="7771234567",
        correo="carlos@gmail.com",
        direccion="Temixco, Morelos",
        totalCompras=450.00,
        estado=True
    ),
    Cliente(
        id=2,
        nombre="María López",
        telefono="7779876543",
        correo="maria@gmail.com",
        direccion="Cuernavaca, Morelos",
        totalCompras=780.50,
        estado=True
    )
]
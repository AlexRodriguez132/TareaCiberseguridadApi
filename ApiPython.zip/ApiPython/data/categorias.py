from models.categoria import Categoria

categorias = [
    Categoria(
        id=1,
        nombre="Bebidas",
        descripcion="Productos para hidratarse"
    ),
    Categoria(
        id=2,
        nombre="Dulces",
        descripcion="Dulces y golosinas"
    )
]
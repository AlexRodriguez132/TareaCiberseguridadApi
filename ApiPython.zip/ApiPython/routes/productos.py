from fastapi import APIRouter, HTTPException
from models.producto import Producto, ProductoBase
from data.productos import productos

router = APIRouter()


@router.post("/products", status_code=201)
def crear_producto(producto: ProductoBase):
    nuevo_producto = Producto(
        id=len(productos) + 1,
        **producto.model_dump()
    )

    productos.append(nuevo_producto)

    return nuevo_producto


@router.get("/products")
def obtener_productos():
    return productos


@router.get("/products/{id}")
def obtener_producto(id: int):
    for producto in productos:
        if producto.id == id:
            return producto

    raise HTTPException(
        status_code=404,
        detail="Producto no encontrado"
    )


@router.put("/products/{id}")
def actualizar_producto(id: int, producto: ProductoBase):
    for producto_actual in productos:
        if producto_actual.id == id:
            producto_actual.nombre = producto.nombre
            producto_actual.descripcion = producto.descripcion
            producto_actual.precio = producto.precio
            producto_actual.marca = producto.marca
            producto_actual.categoria_id = producto.categoria_id
            producto_actual.stock = producto.stock
            producto_actual.estado = producto.estado

            return producto_actual

    raise HTTPException(
        status_code=404,
        detail="Producto no encontrado"
    )


@router.delete("/products/{id}")
def eliminar_producto(id: int):
    for producto in productos:
        if producto.id == id:
            productos.remove(producto)
            return producto

    raise HTTPException(
        status_code=404,
        detail="Producto no encontrado"
    )


@router.get("/products/low-stock")
def obtener_productos_stock_bajo():
    resultado = []

    for producto in productos:
        if producto.stock <= 5:
            resultado.append(producto)

    return resultado
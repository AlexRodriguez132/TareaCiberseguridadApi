from fastapi import FastAPI, APIRouter
from models.categoria import Categoria, CategoriaBase
from data.categorias import categorias
from models.producto import ProductoBase
from data.productos import productos

router = APIRouter()

@router.post("/categories")
def crear_categoria(categoria: CategoriaBase):
    nueva_categoria = Categoria(
        id=len(categorias) + 1,
        **categoria.model_dump()
    )

    categorias.append(nueva_categoria)
    return nueva_categoria

@router.get("/categories")
def obtener_categorias():
    resultado = []

    for categoria in categorias:
        cantidad_productos = 0

        for producto in productos:
            if producto.categoria_id == categoria.id:
                cantidad_productos += 1

        resultado.append({
            "id": categoria.id,
            "nombre": categoria.nombre,
            "descripcion": categoria.descripcion,
            "cantidadProductos": cantidad_productos
        })
    return resultado

@router.get("/categories/{id}")
def obtener_categoria(id: int):
    for categoria in categorias:
        if categoria.id == id:
            return categoria
    return {"erreor": "Categoría no encontrada"}

@router.put("/categories/{id}")
def actualizar_categoria(id: int, categoria: CategoriaBase):
    for categoria_actual in categorias:
        if categoria_actual.id == id:
            categoria_actual.nombre = categoria.nombre
            categoria_actual.descripcion = categoria.descripcion
            return categoria_actual
    return {"error": "Categoría no encontrada"}

@router.delete("/categories/{id}")
def eliminar_categoria(id:int):
    for categoria in categorias:
        if categoria.id == id:
            categorias.remove(categoria)
            return categoria
    return {"error": "Categoría no encontrada"}


from fastapi import APIRouter, HTTPException
from models.cliente import Cliente, ClienteBase
from data.clientes import clientes

router = APIRouter()


@router.post("/customers", status_code=201)
def crear_cliente(cliente: ClienteBase):
    nuevo_cliente = Cliente(
        id=len(clientes) + 1,
        **cliente.model_dump()
    )

    clientes.append(nuevo_cliente)

    return nuevo_cliente


@router.get("/customers")
def obtener_clientes():
    return clientes


@router.get("/customers/{id}")
def obtener_cliente(id: int):
    for cliente in clientes:
        if cliente.id == id:
            return cliente

    raise HTTPException(
        status_code=404,
        detail="Cliente no encontrado"
    )


@router.put("/customers/{id}")
def actualizar_cliente(id: int, cliente: ClienteBase):
    for cliente_actual in clientes:
        if cliente_actual.id == id:
            cliente_actual.nombre = cliente.nombre
            cliente_actual.telefono = cliente.telefono
            cliente_actual.correo = cliente.correo
            cliente_actual.direccion = cliente.direccion
            cliente_actual.totalCompras = cliente.totalCompras
            cliente_actual.estado = cliente.estado

            return cliente_actual

    raise HTTPException(
        status_code=404,
        detail="Cliente no encontrado"
    )


@router.delete("/customers/{id}")
def eliminar_cliente(id: int):
    for cliente in clientes:
        if cliente.id == id:
            clientes.remove(cliente)
            return cliente

    raise HTTPException(
        status_code=404,
        detail="Cliente no encontrado"
    )
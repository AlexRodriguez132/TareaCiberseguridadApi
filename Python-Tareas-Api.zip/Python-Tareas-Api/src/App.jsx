import { Route, Routes } from "react-router-dom"
import Dashboard from "./pages/dashboard/Dashboard"
import Products from "./pages/products/Products"
import Categories from "./pages/categories/Categories"
import Inventory from "./pages/inventory/Inventory"
import Customers from "./pages/clientes/Customers"

function App() {
  return (
    <Routes>
        <Route path="/" to="/dashboard"/>
        <Route path="/dashboard" element={<Dashboard/>}/>
        <Route path="/products" element={<Products/>}/>
        <Route path="/categories" element={<Categories/>}/>
        <Route path="/inventory" element={<Inventory/>}/>
        <Route path="/customers" element={<Customers/>}/>
    </Routes>
  )
}

export default App

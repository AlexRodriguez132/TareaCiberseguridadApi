import { useEffect, useState } from "react";
import Sidebar from "../../components/Sidebar";
import "./dashboard.css";

export default function Dashboard() {
    const [productos, setProductos] = useState([]);
    const [clientes, setClientes] = useState([]);
    const [categorias, setCategorias] = useState([]);
    const [busqueda, setBusqueda] = useState("");

    useEffect(() => {
        cargarDatos();
    }, []);

    const cargarDatos = async () => {
        try {
            const [productosResponse, clientesResponse, categoriasResponse] = await Promise.all([
                fetch("http://localhost:8000/products"),
                fetch("http://localhost:8000/customers"),
                fetch("http://localhost:8000/categories")
            ]);

            if (!productosResponse.ok || !clientesResponse.ok || !categoriasResponse.ok) {
                throw new Error("Error al obtener los datos");
            }

            const productosData = await productosResponse.json();
            const clientesData = await clientesResponse.json();
            const categoriasData = await categoriasResponse.json();

            setProductos(productosData);
            setClientes(clientesData);
            setCategorias(categoriasData);
        } catch (error) {
            console.error("Error:", error);
        }
    };

    const productosActivos = productos.filter(producto => producto.estado);
    const productosStockBajo = productos.filter(producto => producto.stock <= 5);
    const clientesActivos = clientes.filter(cliente => cliente.estado);

    const valorInventario = productos.reduce(
        (total, producto) => total + producto.precio * producto.stock,
        0
    );

    const comprasAcumuladas = clientes.reduce(
        (total, cliente) => total + cliente.totalCompras,
        0
    );

    const productosFiltrados = productos.filter(producto =>
        producto.nombre.toLowerCase().includes(busqueda.toLowerCase())
    );

    return (
        <div className="main-container">
            <Sidebar />

            <div className="principal-content">
                <div className="topbar">
                    <div>
                        <span>Dashboard</span>
                    </div>

                    <div className="div-search-container">
                        <div className="div-search-icon">
                            <svg xmlns="http://www.w3.org/2000/svg" width="35" height="35" viewBox="0 0 24 24" fill="none">
                                <path d="M10.5 19C12.48 19 14.31 18.31 15.75 17.17L20 21.42L21.41 20.01L17.16 15.76C18.3433 14.2658 18.9881 12.4161 18.99 10.51C18.99 5.82 15.18 2.01 10.49 2.01C5.8 2.01 2 5.81 2 10.5C2 15.19 5.81 19 10.5 19ZM10.5 4C14.08 4 17 6.92 17 10.5C17 14.08 14.08 17 10.5 17C6.92 17 4 14.08 4 10.5C4 6.92 6.92 4 10.5 4Z" fill="#5D5FEF" />
                            </svg>
                        </div>

                        <input className="input-search-container"placeholder="Busca un producto..."value={busqueda}onChange={e => setBusqueda(e.target.value)}/>
                    </div>

                    <div>
                        <button className="btn-logout">Logout</button>
                    </div>
                </div>

                <div className="dashboard-card-container">
                    <div className="dashboard-cards-row-one">
                        <div className="dashboard-card">
                            <span className="dashboard-card-title">Productos</span>
                            <strong className="dashboard-card-value">{productos.length}</strong>
                            <span className="dashboard-card-info">{productosActivos.length} activos</span>
                        </div>

                        <div className="dashboard-card">
                            <span className="dashboard-card-title">Clientes</span>
                            <strong className="dashboard-card-value">{clientes.length}</strong>
                            <span className="dashboard-card-info">{clientesActivos.length} activos</span>
                        </div>

                        <div className="dashboard-card">
                            <div className="dashboard-card-header">
                                <h2>Productos</h2>
                            </div>

                            <table>
                                <thead>
                                    <tr className="table-category-titles">
                                        <th>Producto</th>
                                        <th>Precio</th>
                                        <th>Stock</th>
                                        <th>Estado</th>
                                    </tr>
                                </thead>

                                <tbody>
                                    {productosFiltrados.map(producto => (
                                        <tr className="table-category-row" key={producto.id}>
                                            <td>{producto.nombre}</td>
                                            <td>${producto.precio.toFixed(2)}</td>
                                            <td>{producto.stock}</td>
                                            <td>{producto.estado ? "Activo" : "Inactivo"}</td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    </div>

                    <div className="dashboard-cards-row-two">
                        <div className="dashboard-card">
                            <span className="dashboard-card-title">Inventario</span>
                            <strong className="dashboard-card-value">${valorInventario.toFixed(2)}</strong>
                            <span className="dashboard-card-info">{productosStockBajo.length} productos con stock bajo</span>
                        </div>

                        <div className="dashboard-card">
                            <span className="dashboard-card-title">Compras acumuladas</span>
                            <strong className="dashboard-card-value">${comprasAcumuladas.toFixed(2)}</strong>
                            <span className="dashboard-card-info">{clientesActivos.length} clientes activos</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}
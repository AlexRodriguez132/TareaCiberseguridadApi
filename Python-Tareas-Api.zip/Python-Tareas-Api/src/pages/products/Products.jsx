import { useEffect, useState } from "react"
import Sidebar from "../../components/Sidebar"
import "./products.css"

export default function Products() {
    const [productos, setProductos] = useState([])
    const [categorias, setCategorias] = useState([])
    const [isModalOpen, setIsModalOpen] = useState(false)
    const [isEditModalOpen, setIsEditModalOpen] = useState(false)
    const [busqueda, setBusqueda] = useState("")
    const [formularioGuardar, setFormularioGuardar] = useState({
        nombre: "",
        descripcion: "",
        precio: "",
        categoria_id: "",
        marca: "",
        stock: "",
        estado: ""
    })

    const [formularioEditar, setFormularioEditar] = useState({
        nombre: "",
        descripcion: "",
        precio: "",
        categoria_id: "",
        marca: "",
        stock: "",
        estado: ""
    })

    const [productoEditando, setProductoEditando] = useState(null)

    useEffect(() => {
        fetch("http://localhost:8000/products")
            .then(response => response.json())
            .then(data => setProductos(data))

        fetch("http://localhost:8000/categories")
            .then(response => response.json())
            .then(data => setCategorias(data))
    }, [])

    const guardarProducto = () => {
        fetch("http://localhost:8000/products", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                ...formularioGuardar,
                precio: Number(formularioGuardar.precio),
                stock: Number(formularioGuardar.stock),
                estado: formularioGuardar.estado === "activo"
            })
        })
            .then(response => response.json())
            .then(data => {
                setProductos([...productos, data])

                setFormularioGuardar({
                    nombre: "",
                    descripcion: "",
                    precio: "",
                    categoria_id: "",
                    marca: "",
                    stock: "",
                    estado: ""
                })

                setIsModalOpen(false)
            })
    }

    const editarProducto = (producto) => {
        setProductoEditando(producto)

        setFormularioEditar({
            nombre: producto.nombre,
            descripcion: producto.descripcion,
            precio: producto.precio,
            categoria_id: producto.categoria_id,
            marca: producto.marca,
            stock: producto.stock,
            estado: producto.estado ? "activo" : "inactivo"
        })

        setIsEditModalOpen(true)
    }

    const actualizarProducto = () => {
        fetch(`http://localhost:8000/products/${productoEditando.id}`, {
            method: "PUT",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                ...formularioEditar,
                precio: Number(formularioEditar.precio),
                stock: Number(formularioEditar.stock),
                estado: formularioEditar.estado === "activo"
            })
        })
            .then(response => response.json())
            .then(data => {
                setProductos(productos.map(producto => producto.id === data.id ? data : producto))

                setFormularioEditar({
                    nombre: "",
                    descripcion: "",
                    precio: "",
                    categoria: "",
                    marca: "",
                    stock: "",
                    estado: ""
                })

                setProductoEditando(null)
                setIsEditModalOpen(false)
            })
    }

    const eliminarProducto = (id) => {
        fetch(`http://localhost:8000/products/${id}`, {
            method: "DELETE"
        })
        .then(response => response.json())
        .then(data => {
            setProductos(productos.filter(producto => producto.id !== data.id))
        })
    }

    const productosFiltrados = productos.filter(producto =>
        producto.nombre.toLowerCase().includes(busqueda.toLowerCase()) ||
        producto.descripcion.toLowerCase().includes(busqueda.toLowerCase()) ||
        producto.marca.toLowerCase().includes(busqueda.toLowerCase())
    )

    return (
        <div className="main-container">
            <Sidebar />

            <div className="principal-content">
                <div className="topbar">
                    <div>
                        <span>Productos</span>
                    </div>

                    <div className="div-search-container">
                        <div className="div-search-icon">
                            <svg xmlns="http://www.w3.org/2000/svg" width="35" height="35" viewBox="0 0 24 24" fill="none">
                                <path d="M10.5 19C12.48 19 14.31 18.31 15.75 17.17L20 21.42L21.41 20.01L17.16 15.76C18.3433 14.2658 18.9881 12.4161 18.99 10.51C18.99 5.82 15.18 2.01 10.49 2.01C5.8 2.01 2 5.81 2 10.5C2 15.19 5.81 19 10.5 19ZM10.5 4C14.08 4 17 6.92 17 10.5C17 14.08 14.08 17 10.5 17C6.92 17 4 14.08 4 10.5C4 6.92 6.92 4 10.5 4Z" fill="#5D5FEF" />
                            </svg>
                        </div>

                        <input className="input-search-container" placeholder="Busca algo..." />
                    </div>

                    <div>
                        <button className="btn-logout">Logout</button>
                    </div>
                </div>

                <div className="products-container">
                    <div className="products-header">
                        <div className="div-btn-create-product">
                            <svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" viewBox="0 0 30 30" fill="none">
                                <path d="M26.25 15C26.25 8.78906 21.2109 3.75 15 3.75C8.78906 3.75 3.75 8.78906 3.75 15C3.75 21.2109 8.78906 26.25 15 26.25C21.2109 26.25 26.25 21.2109 26.25 15Z" stroke="white" stroke-width="2" stroke-miterlimit="10" />
                                <path d="M15 10.3125V19.6875M19.6875 15H10.3125" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                            </svg>

                            <button className="btn-create-product" onClick={() => setIsModalOpen(true)}>Añadir Producto</button>
                        </div>

                        <div className="div-input-search-product">
                            <div className="div-search-product-icon">
                                <svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" viewBox="0 0 24 24" fill="none">
                                    <path d="M10.5 19C12.48 19 14.31 18.31 15.75 17.17L20 21.42L21.41 20.01L17.16 15.76C18.3433 14.2658 18.9881 12.4161 18.99 10.51C18.99 5.82 15.18 2.01 10.49 2.01C5.8 2.01 2 5.81 2 10.5C2 15.19 5.81 19 10.5 19ZM10.5 4C14.08 4 17 6.92 17 10.5C17 14.08 14.08 17 10.5 17C6.92 17 4 14.08 4 10.5C4 6.92 6.92 4 10.5 4Z" fill="#5D5FEF" />
                                </svg>
                            </div>

                            <input className="input-search-product" placeholder="Busca un producto..." value={busqueda} onChange={(e) => setBusqueda(e.target.value)}
                            />
                        </div>
                    </div>

                    <table className="table-products">
                        <thead>
                            <tr className="table-product-titles">
                                <th>Nombre</th>
                                <th>Descripción</th>
                                <th>Precio</th>
                                <th>Categoría</th>
                                <th>Marca</th>
                                <th>Stock</th>
                                <th>Estado</th>
                                <th>Acciones</th>
                            </tr>
                        </thead>

                        <tbody>
                            {productosFiltrados.map(producto => (
                                <tr className="table-product-row" key={producto.id}>
                                    <td>{producto.nombre}</td>
                                    <td>{producto.descripcion}</td>
                                    <td>${producto.precio.toFixed(2)}</td>
                                    <td>{categorias.find(categoria => categoria.id === producto.categoria_id)?.nombre}</td>
                                    <td>{producto.marca}</td>
                                    <td>{producto.stock}</td>
                                    <td>{producto.estado ? "Activo" : "Inactivo"}</td>

                                    <td>
                                        <button className="btn-edit-product" onClick={() => editarProducto(producto)}>Editar</button>
                                        <button className="btn-delete-product" onClick={() => eliminarProducto(producto.id)}>Eliminar</button>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>

                    <div className="table-pagination">
                        <span className="pagination-info">Mostrando 1 - 1 de 1</span>

                        <div className="pagination-buttons">
                            <button className="btn-page" disabled>&lt;</button>
                            <button className="btn-page">&gt;</button>
                        </div>
                    </div>

                    {isModalOpen && (
                        <div className="modal-overlay">
                            <div className="modal-card">
                                <h3>Añadir Producto</h3>

                                <div className="modal-form">
                                    <input type="text" placeholder="Nombre" value={formularioGuardar.nombre} onChange={(e) => setFormularioGuardar({ ...formularioGuardar, nombre: e.target.value })} />
                                    <textarea placeholder="Descripción" value={formularioGuardar.descripcion} onChange={(e) => setFormularioGuardar({ ...formularioGuardar, descripcion: e.target.value })} />
                                    <input type="text" placeholder="Precio" value={formularioGuardar.precio} onChange={(e) => setFormularioGuardar({ ...formularioGuardar, precio: e.target.value })} />
                                    <select className="modal-select" value={formularioGuardar.categoria_id} onChange={(e) => setFormularioGuardar({ ...formularioGuardar, categoria_id: Number(e.target.value) })}>
                                        <option value="" disabled>Selecciona categoría</option>
                                        {categorias.map(categoria => (
                                            <option key={categoria.id} value={categoria.id}>{categoria.nombre}</option>
                                        ))}
                                    </select>
                                    <input type="text" placeholder="Marca" value={formularioGuardar.marca} onChange={(e) => setFormularioGuardar({ ...formularioGuardar, marca: e.target.value })} />
                                    <input type="text" placeholder="Stock" value={formularioGuardar.stock} onChange={(e) => setFormularioGuardar({ ...formularioGuardar, stock: e.target.value })} />

                                    <select className="modal-select" value={formularioGuardar.estado} onChange={(e) => setFormularioGuardar({ ...formularioGuardar, estado: e.target.value })}>
                                        <option value="" disabled>Selecciona estado</option>
                                        <option value="activo">Activo</option>
                                        <option value="inactivo">Inactivo</option>
                                    </select>
                                </div>

                                <div className="modal-buttons">
                                    <button className="btn-cancel-create-product" onClick={() => setIsModalOpen(false)}>Cancelar</button>
                                    <button className="btn-save-create-product" onClick={guardarProducto}>Guardar</button>
                                </div>
                            </div>
                        </div>
                    )}

                    {isEditModalOpen && (
                        <div className="modal-overlay">
                            <div className="modal-card">
                                <h3>Editar Producto</h3>

                                <div className="modal-form">
                                    <input type="text" placeholder="Nombre" value={formularioEditar.nombre} onChange={(e) => setFormularioEditar({ ...formularioEditar, nombre: e.target.value })} />
                                    <textarea placeholder="Descripción" value={formularioEditar.descripcion} onChange={(e) => setFormularioEditar({ ...formularioEditar, descripcion: e.target.value })} />
                                    <input type="text" placeholder="Precio" value={formularioEditar.precio} onChange={(e) => setFormularioEditar({ ...formularioEditar, precio: e.target.value })} />
                                    <select className="modal-select" value={formularioEditar.categoria_id} onChange={(e) => setFormularioEditar({ ...formularioEditar, categoria_id: Number(e.target.value) })}>
                                        <option value="" disabled>Selecciona categoría</option>
                                        {categorias.map(categoria => (
                                            <option key={categoria.id} value={categoria.id}>{categoria.nombre}</option>
                                        ))}
                                    </select>
                                    <input type="text" placeholder="Marca" value={formularioEditar.marca} onChange={(e) => setFormularioEditar({ ...formularioEditar, marca: e.target.value })} />
                                    <input type="text" placeholder="Stock" value={formularioEditar.stock} onChange={(e) => setFormularioEditar({ ...formularioEditar, stock: e.target.value })} />

                                    <select className="modal-select" value={formularioEditar.estado} onChange={(e) => setFormularioEditar({ ...formularioEditar, estado: e.target.value })}>
                                        <option value="" disabled>Selecciona estado</option>
                                        <option value="activo">Activo</option>
                                        <option value="inactivo">Inactivo</option>
                                    </select>
                                </div>

                                <div className="modal-buttons">
                                    <button className="btn-cancel-create-product" onClick={() => setIsEditModalOpen(false)}>Cancelar</button>
                                    <button className="btn-save-create-product" onClick={actualizarProducto}>Actualizar</button>
                                </div>
                            </div>
                        </div>
                    )}
                    
                </div>
            </div>
        </div>
    )
}
import Sidebar from "../../components/Sidebar";
import "./inventory.css"
export default function Inventory() {
    return (
        <div className="main-container">
            <Sidebar />
            <div className="principal-content">
                <div className="topbar">
                    <div>
                        <span>Inventario</span>
                    </div>
                    <div className="div-search-container">
                        <div className="div-search-icon">
                            <svg xmlns="http://www.w3.org/2000/svg" width="35" height="35" viewBox="0 0 24 24" fill="none">
                                <path d="M10.5 19C12.48 19 14.31 18.31 15.75 17.17L20 21.42L21.41 20.01L17.16 15.76C18.3433 14.2658 18.9881 12.4161 18.99 10.51C18.99 5.82 15.18 2.01 10.49 2.01C5.8 2.01 2 5.81 2 10.5C2 15.19 5.81 19 10.5 19ZM10.5 4C14.08 4 17 6.92 17 10.5C17 14.08 14.08 17 10.5 17C6.92 17 4 14.08 4 10.5C4 6.92 6.92 4 10.5 4Z" fill="#5D5FEF" />
                            </svg>
                        </div>
                        <input className="input-search-container" placeholder="Busca algo..." />
                    </div>
                    <div>
                        <button className="btn-logout">Logout</button>
                    </div>
                </div>
                <div className="inventory-container">
                    <div className="inventory-header">
                        <div className="div-input-search-inventory">
                            <div className="div-search-inventory-icon">
                                <svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" viewBox="0 0 24 24" fill="none">
                                    <path d="M10.5 19C12.48 19 14.31 18.31 15.75 17.17L20 21.42L21.41 20.01L17.16 15.76C18.3433 14.2658 18.9881 12.4161 18.99 10.51C18.99 5.82 15.18 2.01 10.49 2.01C5.8 2.01 2 5.81 2 10.5C2 15.19 5.81 19 10.5 19ZM10.5 4C14.08 4 17 6.92 17 10.5C17 14.08 14.08 17 10.5 17C6.92 17 4 14.08 4 10.5C4 6.92 6.92 4 10.5 4Z" fill="#5D5FEF" />
                                </svg>
                            </div>
                            <input className="input-search-inventory" placeholder="Buscar en inventario..." />
                        </div>
                    </div>
                    <table className="table-inventory">
                        <thead>
                            <tr className="table-inventory-titles">
                                <th>Producto</th>
                                <th>Stock</th>
                                <th>Estado</th>
                                <th>Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr className="table-inventory-row">
                                <td>Teclado Mecánico</td>
                                <td>15</td>
                                <td>Disponible</td>
                                <td>
                                    <button className="btn-edit-inventory">Editar</button>
                                </td>
                            </tr>
                        </tbody>
                    </table>

                    <div className="table-pagination">
                        <span className="pagination-info">Mostrando 1 - 1 de 1</span>
                        <div className="pagination-buttons">
                            <button className="btn-page" disabled>&lt;</button>
                            <button className="btn-page">&gt;</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}
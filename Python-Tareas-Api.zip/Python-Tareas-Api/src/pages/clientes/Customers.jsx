import { useEffect, useState } from "react"
import Sidebar from "../../components/Sidebar"
import "./customers.css"

export default function Customers() {
    const [clientes, setClientes] = useState([])
    const [isModalOpen, setIsModalOpen] = useState(false)
    const [isEditModalOpen, setIsEditModalOpen] = useState(false)
    const [clienteEditando, setClienteEditando] = useState(null)
    const [busqueda, setBusqueda] = useState("")
    const [formularioGuardar, setFormularioGuardar] = useState({
        nombre: "",
        telefono: "",
        correo: "",
        direccion: "",
        totalCompras: "",
        estado: "activo"
    })

    const [formularioEditar, setFormularioEditar] = useState({
        nombre: "",
        telefono: "",
        correo: "",
        direccion: "",
        totalCompras: "",
        estado: "activo"
    })

    useEffect(() => {
        fetch("http://localhost:8000/customers")
            .then(response => response.json())
            .then(data => setClientes(data))
    }, [])

    const guardarCliente = () => {
        fetch("http://localhost:8000/customers", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                ...formularioGuardar,
                totalCompras: Number(formularioGuardar.totalCompras),
                estado: formularioGuardar.estado === "activo"
            })
        })
            .then(response => response.json())
            .then(data => {
                setClientes([...clientes, data])

                setFormularioGuardar({
                    nombre: "",
                    telefono: "",
                    correo: "",
                    direccion: "",
                    totalCompras: "",
                    estado: "activo"
                })

                setIsModalOpen(false)
            })
    }

    const editarCliente = (cliente) => {
        setClienteEditando(cliente)

        setFormularioEditar({
            nombre: cliente.nombre,
            telefono: cliente.telefono,
            correo: cliente.correo,
            direccion: cliente.direccion,
            totalCompras: cliente.totalCompras,
            estado: cliente.estado ? "activo" : "inactivo"
        })

        setIsEditModalOpen(true)
    }

    const actualizarCliente = () => {
        fetch(`http://localhost:8000/customers/${clienteEditando.id}`, {
            method: "PUT",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                ...formularioEditar,
                totalCompras: Number(formularioEditar.totalCompras),
                estado: formularioEditar.estado === "activo"
            })
        })
            .then(response => response.json())
            .then(data => {
                setClientes(clientes.map(cliente =>
                    cliente.id === data.id ? data : cliente
                ))

                setFormularioEditar({
                    nombre: "",
                    telefono: "",
                    correo: "",
                    direccion: "",
                    totalCompras: "",
                    estado: "activo"
                })

                setClienteEditando(null)
                setIsEditModalOpen(false)
            })
    }

    const eliminarCliente = (id) => {
        fetch(`http://localhost:8000/customers/${id}`, {
            method: "DELETE"
        })
            .then(response => response.json())
            .then(data => {
                setClientes(clientes.filter(cliente => cliente.id !== data.id))
            })
    }
    
    const clientesFiltrados = clientes.filter(cliente =>
        cliente.nombre.toLowerCase().includes(busqueda.toLowerCase()) ||
        cliente.telefono.includes(busqueda) ||
        cliente.correo.toLowerCase().includes(busqueda.toLowerCase()) ||
        cliente.direccion.toLowerCase().includes(busqueda.toLowerCase())
    )

    return (
        <div className="main-container">
            <Sidebar />

            <div className="principal-content">
                <div className="topbar">
                    <div>
                        <span>Clientes</span>
                    </div>

                    <div className="div-search-container">
                        <div className="div-search-icon">
                            <svg xmlns="http://www.w3.org/2000/svg" width="35" height="35" viewBox="0 0 24 24" fill="none">
                                <path d="M10.5 19C12.48 19 14.31 18.31 15.75 17.17L20 21.42L21.41 20.01L17.16 15.76C18.3433 14.2658 18.9881 12.4161 18.99 10.51C18.99 5.82 15.18 2.01 10.49 2.01C5.8 2.01 2 5.81 2 10.5C2 15.19 5.81 19 10.5 19ZM10.5 4C14.08 4 17 6.92 17 10.5C17 14.08 14.08 17 10.5 17C6.92 17 4 14.08 4 10.5C4 6.92 6.92 4 10.5 4Z" fill="#5D5FEF" />
                            </svg>
                        </div>

                        <input type="text" className="input-search-category" placeholder="Busca un cliente..." value={busqueda} onChange={(e) => setBusqueda(e.target.value)}/>
                    </div>

                    <div>
                        <button className="btn-logout">Logout</button>
                    </div>
                </div>

                <div className="categories-container">
                    <div className="categories-header">
                        <div className="div-btn-create-category">
                            <svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" viewBox="0 0 30 30" fill="none">
                                <path d="M26.25 15C26.25 8.78906 21.2109 3.75 15 3.75C8.78906 3.75 3.75 8.78906 3.75 15C3.75 21.2109 8.78906 26.25 15 26.25C21.2109 26.25 26.25 21.2109 26.25 15Z" stroke="white" strokeWidth="2" strokeMiterlimit="10" />
                                <path d="M15 10.3125V19.6875M19.6875 15H10.3125" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                            </svg>

                            <button
                                className="btn-create-category"
                                onClick={() => setIsModalOpen(true)}
                            >
                                Añadir cliente
                            </button>
                        </div>

                        <div className="div-input-search-category">
                            <div className="search-category-icon">
                                <svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" viewBox="0 0 24 24" fill="none">
                                    <path d="M10.5 19C12.48 19 14.31 18.31 15.75 17.17L20 21.42L21.41 20.01L17.16 15.76C18.3433 14.2658 18.9881 12.4161 18.99 10.51C18.99 5.82 15.18 2.01 10.49 2.01C5.8 2.01 2 5.81 2 10.5C2 15.19 5.81 19 10.5 19ZM10.5 4C14.08 4 17 6.92 17 10.5C17 14.08 14.08 17 14.08 17C6.92 17 4 14.08 4 10.5C4 6.92 6.92 4 10.5 4Z" fill="#5D5FEF" />
                                </svg>
                            </div>

                            <input
                                type="text"
                                className="input-search-category"
                                placeholder="Busca un cliente..."
                                value={busqueda}
                                onChange={(e) => setBusqueda(e.target.value)}
                            />
                        </div>
                    </div>

                    <table className="table-categories">
                        <thead>
                            <tr className="table-category-titles">
                                <th>Nombre</th>
                                <th>Teléfono</th>
                                <th>Correo</th>
                                <th>Dirección</th>
                                <th>Total de compras</th>
                                <th>Acciones</th>
                            </tr>
                        </thead>

                        <tbody>
                            {clientesFiltrados.map(cliente => (
                                <tr className="table-category-row" key={cliente.id}>
                                    <td>{cliente.nombre}</td>
                                    <td>{cliente.telefono}</td>
                                    <td>{cliente.correo}</td>
                                    <td>{cliente.direccion}</td>
                                    <td>${cliente.totalCompras.toFixed(2)}</td>
                                    <td>
                                        <button
                                            className="btn-edit-category"
                                            onClick={() => editarCliente(cliente)}
                                        >
                                            Editar
                                        </button>

                                        <button
                                            className="btn-delete-category"
                                            onClick={() => eliminarCliente(cliente.id)}
                                        >
                                            Eliminar
                                        </button>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>

                    <div className="table-pagination">
                        <span className="pagination-info">
                            Mostrando 1 - {clientes.length} de {clientes.length}
                        </span>

                        <div className="pagination-buttons">
                            <button className="btn-page" disabled>
                                &lt;
                            </button>

                            <button className="btn-page">
                                &gt;
                            </button>
                        </div>
                    </div>
                </div>
            </div>

            {isModalOpen && (
                <div className="modal-overlay">
                    <div className="modal-card">
                        <h3>Añadir cliente</h3>

                        <div className="modal-form">
                            <input
                                type="text"
                                placeholder="Nombre"
                                value={formularioGuardar.nombre}
                                onChange={(e) => setFormularioGuardar({
                                    ...formularioGuardar,
                                    nombre: e.target.value
                                })}
                            />

                            <input
                                type="text"
                                placeholder="Teléfono"
                                value={formularioGuardar.telefono}
                                onChange={(e) => setFormularioGuardar({
                                    ...formularioGuardar,
                                    telefono: e.target.value
                                })}
                            />

                            <input
                                type="email"
                                placeholder="Correo"
                                value={formularioGuardar.correo}
                                onChange={(e) => setFormularioGuardar({
                                    ...formularioGuardar,
                                    correo: e.target.value
                                })}
                            />

                            <input
                                type="text"
                                placeholder="Dirección"
                                value={formularioGuardar.direccion}
                                onChange={(e) => setFormularioGuardar({
                                    ...formularioGuardar,
                                    direccion: e.target.value
                                })}
                            />

                            <input
                                type="number"
                                placeholder="Total de compras"
                                value={formularioGuardar.totalCompras}
                                onChange={(e) => setFormularioGuardar({
                                    ...formularioGuardar,
                                    totalCompras: e.target.value
                                })}
                            />

                            <select
                                value={formularioGuardar.estado}
                                onChange={(e) => setFormularioGuardar({
                                    ...formularioGuardar,
                                    estado: e.target.value
                                })}
                            >
                                <option value="activo">Activo</option>
                                <option value="inactivo">Inactivo</option>
                            </select>
                        </div>

                        <div className="modal-buttons">
                            <button
                                className="btn-cancel-create-category"
                                onClick={() => setIsModalOpen(false)}
                            >
                                Cancelar
                            </button>

                            <button
                                className="btn-save-create-category"
                                onClick={guardarCliente}
                            >
                                Guardar
                            </button>
                        </div>
                    </div>
                </div>
            )}

            {isEditModalOpen && (
                <div className="modal-overlay">
                    <div className="modal-card">
                        <h3>Editar cliente</h3>

                        <div className="modal-form">
                            <input
                                type="text"
                                placeholder="Nombre"
                                value={formularioEditar.nombre}
                                onChange={(e) => setFormularioEditar({
                                    ...formularioEditar,
                                    nombre: e.target.value
                                })}
                            />

                            <input
                                type="text"
                                placeholder="Teléfono"
                                value={formularioEditar.telefono}
                                onChange={(e) => setFormularioEditar({
                                    ...formularioEditar,
                                    telefono: e.target.value
                                })}
                            />

                            <input
                                type="email"
                                placeholder="Correo"
                                value={formularioEditar.correo}
                                onChange={(e) => setFormularioEditar({
                                    ...formularioEditar,
                                    correo: e.target.value
                                })}
                            />

                            <input
                                type="text"
                                placeholder="Dirección"
                                value={formularioEditar.direccion}
                                onChange={(e) => setFormularioEditar({
                                    ...formularioEditar,
                                    direccion: e.target.value
                                })}
                            />

                            <input
                                type="number"
                                placeholder="Total de compras"
                                value={formularioEditar.totalCompras}
                                onChange={(e) => setFormularioEditar({
                                    ...formularioEditar,
                                    totalCompras: e.target.value
                                })}
                            />

                            <select
                                value={formularioEditar.estado}
                                onChange={(e) => setFormularioEditar({
                                    ...formularioEditar,
                                    estado: e.target.value
                                })}
                            >
                                <option value="activo">Activo</option>
                                <option value="inactivo">Inactivo</option>
                            </select>
                        </div>

                        <div className="modal-buttons">
                            <button
                                className="btn-cancel-create-category"
                                onClick={() => setIsEditModalOpen(false)}
                            >
                                Cancelar
                            </button>

                            <button
                                className="btn-save-create-category"
                                onClick={actualizarCliente}
                            >
                                Guardar
                            </button>
                        </div>
                    </div>
                </div>
            )}
        </div>
    )
}
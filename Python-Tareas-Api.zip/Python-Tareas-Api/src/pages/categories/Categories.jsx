import { useEffect, useState } from "react"
import Sidebar from "../../components/Sidebar"
import "./categories.css"
export default function Categories() {
    const [categorias, setCategorias] = useState([]);
    const [isModalOpen, setIsModalOpen] = useState(false)
    const [isEditModalOpen, setIsEditModalOpen] = useState(false)
    const [categoriaEditando, setCategoriaEditando] = useState(null)
    const [formularioGuardar, setFormularioGuardar] = useState({
        nombre: "",
        descripcion: ""
    })
    const [formularioEditar, setFormularioEditar] = useState({
        nombre: "",
        descripcion: ""
    })

    const guardarCategoria = () => {
        fetch("http://localhost:8000/categories", {
            method: "POST",
            headers: {
                "Content-Type" : "application/json"
            },
            body: JSON.stringify(formularioGuardar)
        })
        .then(response => response.json())
        .then(data => {
            setCategorias([...categorias, data])
            setFormularioGuardar({
                nombre: "",
                descripcion: ""
            })
            setIsModalOpen(false)
        })
    }

    const editarCategoria = (categoria) => {
        setCategoriaEditando(categoria)

        setFormularioEditar({
            nombre: categoria.nombre,
            descripcion: categoria.descripcion
        })

        setIsEditModalOpen(true)
    }

    useEffect(() => {
        fetch("http://localhost:8000/categories")
        .then(response => response.json())
        .then(data => setCategorias(data))
    }, [])

    return (
        <div className="main-container">
            <Sidebar />
            <div className="principal-content">
                <div className="topbar">
                    <div>
                        <span>Categorías</span>
                    </div>
                    <div className="div-search-container">
                        <div className="div-search-icon">
                            <svg xmlns="http://www.w3.org/2000/svg" width="35" height="35" viewBox="0 0 24 24" fill="none">
                                <path d="M10.5 19C12.48 19 14.31 18.31 15.75 17.17L20 21.42L21.41 20.01L17.16 15.76C18.3433 14.2658 18.9881 12.4161 18.99 10.51C18.99 5.82 15.18 2.01 10.49 2.01C5.8 2.01 2 5.81 2 10.5C2 15.19 5.81 19 10.5 19ZM10.5 4C14.08 4 17 6.92 17 10.5C17 14.08 14.08 17 10.5 17C6.92 17 4 14.08 4 10.5C4 6.92 6.92 4 10.5 4Z" fill="#5D5FEF" />
                            </svg>
                        </div>
                        <input className="input-search-container" placeholder="Busca algo..." />
                    </div>
                    <div>
                        <button className="btn-logout">Logout</button>
                    </div>
                </div>
                <div className="categories-container">
                    <div className="categories-header">
                        <div className="div-btn-create-category">
                            <svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" viewBox="0 0 30 30" fill="none">
                                <path d="M26.25 15C26.25 8.78906 21.2109 3.75 15 3.75C8.78906 3.75 3.75 8.78906 3.75 15C3.75 21.2109 8.78906 26.25 15 26.25C21.2109 26.25 26.25 21.2109 26.25 15Z" stroke="white" stroke-width="2" stroke-miterlimit="10" />
                                <path d="M15 10.3125V19.6875M19.6875 15H10.3125" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                            </svg>
                            <button className="btn-create-category" onClick={() => setIsModalOpen(true)}>Crear Categoría</button>
                        </div>
                        <div className="div-input-search-category">
                            <div className="search-category-icon">
                                <svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" viewBox="0 0 24 24" fill="none">
                                    <path d="M10.5 19C12.48 19 14.31 18.31 15.75 17.17L20 21.42L21.41 20.01L17.16 15.76C18.3433 14.2658 18.9881 12.4161 18.99 10.51C18.99 5.82 15.18 2.01 10.49 2.01C5.8 2.01 2 5.81 2 10.5C2 15.19 5.81 19 10.5 19ZM10.5 4C14.08 4 17 6.92 17 10.5C17 14.08 14.08 17 10.5 17C6.92 17 4 14.08 4 10.5C4 6.92 6.92 4 10.5 4Z" fill="#5D5FEF" />
                                </svg>
                            </div>
                            <input type="text" className="input-search-category" placeholder="Busca una categoria..." />
                        </div>
                    </div>

                    <table className="table-categories">
                        <thead>
                            <tr className="table-category-titles">
                                <th>Nombre</th>
                                <th>Descripción</th>
                                <th>Cantidad de Productos</th>
                                <th>Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            {categorias.map(categoria => (
                                <tr className="table-category-row" key={categoria.id}>
                                    <td>{categoria.nombre}</td>
                                    <td>{categoria.descripcion}</td>
                                    <td>{categoria.cantidadProductos}</td>
                                    <td>
                                        <button className="btn-edit-category" onClick={() => editarCategoria(categoria)}>Editar</button>
                                        <button className="btn-delete-category">Eliminar</button>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>

                    <div className="table-pagination">
                        <span className="pagination-info">Mostrando 1 - 1 de 1</span>
                        <div className="pagination-buttons">
                            <button className="btn-page" disabled>&lt;</button>
                            <button className="btn-page">&gt;</button>
                        </div>
                    </div>
                </div>
            </div>
            {isModalOpen && (
                <div className="modal-overlay">
                    <div className="modal-card">
                        <h3>Crear Categoría</h3>

                        <div className="modal-form">
                            <input type="text" placeholder="Nombre" value={formularioGuardar.nombre} onChange={(e) => setFormularioGuardar({ ...formularioGuardar, nombre: e.target.value })} />
                            <textarea placeholder="Descripción" value={formularioGuardar.descripcion} onChange={(e) => setFormularioGuardar({ ...formularioGuardar, descripcion: e.target.value })} />
                        </div>

                        <div className="modal-buttons">
                            <button className="btn-cancel-create-category" onClick={() => setIsModalOpen(false)}>Cancelar</button>
                            <button className="btn-save-create-category" onClick={guardarCategoria}>Guardar</button>
                        </div>
                    </div>
                </div>
            )}
            {isEditModalOpen && (
                <div className="modal-overlay">
                    <div className="modal-card">
                        <h3>Editar Categoría</h3>

                        <div className="modal-form">
                            <input
                                type="text"
                                placeholder="Nombre"
                                value={formularioEditar.nombre}
                                onChange={(e) => setFormularioEditar({
                                    ...formularioEditar,
                                    nombre: e.target.value
                                })}
                            />

                            <textarea
                                placeholder="Descripción"
                                value={formularioEditar.descripcion}
                                onChange={(e) => setFormularioEditar({
                                    ...formularioEditar,
                                    descripcion: e.target.value
                                })}
                            />
                        </div>

                        <div className="modal-buttons">
                            <button
                                className="btn-cancel-create-category"
                                onClick={() => setIsEditModalOpen(false)}
                            >
                                Cancelar
                            </button>

                            <button className="btn-save-create-category">
                                Guardar
                            </button>
                        </div>
                    </div>
                </div>
            )}
        </div>
    )
}